"""
local_endpoint_base.py

abstract class that defines LocalEndpoint interface
"""
from endpoint_base import EndpointBase

from logger import TastLogger


class LocalEndpointBase(EndpointBase):
    """
    LocalEndpoint class provides functions for managing local PCoIP endpoint.
    """

    def __init__(
        self, 
        fqdn, 
        username, 
        password,
        type, 
        version,
        viewer_type,
        viewer_id):
        """
        Arguments:
            fqdn: same as for Endpoint
            username: same as for Endpoint
            password: same as for Endpoint
            type: one of LocalEndpointType values
            version: same as for Endpoint
            viewer_type: 'kvmoip' or 'dp-dvi'
            viewer_id: type specific, for 'kvmoip' switch it is fqdn or ipaddr
                of the kvmoip device
        """

        self.log = TastLogger(self.__class__.__name__)
        self.log.debug('LocalEndpointBase: Creating new %s instance...' % (
                                    self.__class__.__name__))
                                    
        super(LocalEndpointBase, self).__init__(
            fqdn,
            username,
            password,
            type,
            version)

        self.viewer_type = viewer_type
        self.viewer_id = viewer_id
        self.connection_interface = None
        
        self.local_endpoint = None

        self.log.debug('LocalEndpointBase: New %s instance created!' % (
                                    self.__class__.__name__))

    # ===== session related functions =====

    def connect_to_remote_endpoint(
        self,
        remote_endpoint,
        connection_interface,
        configuration):
        """
        Arguments:
            RemoteEndpoint remote_endpoint: endpoint to connect to
            string connection_interface: 'ui' (sikuli) or 'api' (cmicl)
            dict configuration: parameters that depend on the client, server and
                connection interface types. For example, when using VMware View
                Client one parameter could be desktop layout (fullscreen or
                window with sepcific size); e.g. dictionary {'desktop_layout': 'fullscreen'}
        Exceptions:
            ConnectionError(description)
        Similar functions:
            softi PcoipClient.create_pcoip_session(pcoip_client, pcoip_server, *args)
            swift SwiftClient*.start_pcoip_session(desktop)+verify_session_start()
            swift SwiftSession.initialize()+create_pcoip_session()
            firmware SessionCtrl.start_session_direct()
        Questions:
            - How do we connect through security gateway? Is that defined by connection server?
        """
        raise Exception('connect_to_remote_endpoint must be implemented in the concrete class!')


    def disconnect_from_remote_endpoint(self, method):
        """
        Arguments: method - e.g. disconnect, disconnect&logoff, tsdiscon, ctrl+alt+F12, etc
        Returns: none
        Exceptions:
            DisconnectionError(description)
        Simialar functions:
            softi PcoipClient.close_pcoip_session()
            swift SwiftClient*.terminate_pcoip_session()
            swift SwiftSession.close_pcoip_session()
            firmware SessionCtrl.stop_session()
        """
        raise Exception('disconnect_from_remote_endpoint must be implemented in the concrete class!')

